#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m" 
#define YELLOW "\x1b[33m"
#define BLUE "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN "\x1b[36m"
#define ERROR_MARGIN 0.5
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>
#include <stdbool.h>

// To enable sub-comm: export MV2_INTER_ALLREDUCE_TUNING=0

#define MAX_SIZE_ROOT 64*1024*1024
#define MAX_SIZE 1024*1024

int main(int argc, char** argv) {

	int DEBUG_LOG =0; 
	if(argv[1]==NULL)
			DEBUG_LOG = 0;
	else
			DEBUG_LOG = atoi(argv[1]);

        MPI_Init(NULL, NULL);

        int my_rank;
        MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
        int world_size;
        MPI_Comm_size(MPI_COMM_WORLD, &world_size);

        MPI_Status status;
        MPI_Comm New_Comm; 

       // float *global_sum =      (float *)malloc(sizeof(float) * MAX_SIZE);
	   // float *subcom_global_sum= (float *)malloc(sizeof(float) * MAX_SIZE);       
       float *input_gsum_buf =  (float *)malloc(sizeof(float) * MAX_SIZE);

	   // float *input_recv_buf =  (float *)malloc(sizeof(float) * MAX_SIZE);
       // float *root_sum_buf =    (float *)malloc(sizeof(float) * MAX_SIZE);
       // float *subcom_rand_nums= (float *)malloc(sizeof(float) * MAX_SIZE);
       // float *subcom_root_sum_buf= (float *)malloc(sizeof(float) * MAX_SIZE);
       
       
       // float *sum  = (float *)malloc(sizeof(float) * world_size);      
       float *rand_nums = (float *)malloc(sizeof(float) * MAX_SIZE);

       int i,j, rank;
       float temp;

       int color = my_rank % 2;
       int new_id, new_world_size, broad_val;

       FILE *fp;

       // rand_nums = create_rand_nums(MAX_SIZE);

       if (my_rank==0){
                for (i = 0; i < MAX_SIZE; i++) {
                        temp = (rand() / (float)RAND_MAX);
                        temp = round(temp*1000);
                        rand_nums[i] = temp;
                        // rand_nums[i] = 1;
                }
                fp = fopen("00.data", "w");

                for (i = 0; i < MAX_SIZE; i++) 
                        fprintf(fp, " %f ", i, rand_nums[i]);
                fclose(fp);
        }

        
#if 0
        if(world_size >= 4){                
                PMPI_Comm_split(MPI_COMM_WORLD, color, my_rank, &New_Comm);
                MPI_Comm_rank(New_Comm, &new_id);
                MPI_Comm_size(New_Comm, &new_world_size);
        }

		if(new_id == 0 ){                
                fprintf(stderr,MAGENTA"[%d] Sub-Comm: new_world_size=%d\n"RESET,my_rank,new_world_size);
		}
#endif
        
        // fprintf(stderr,"[%d] new_id=%d  new_world_size=%d\n",my_rank,new_id,new_world_size);


        MPI_Barrier(MPI_COMM_WORLD);

        int sizes[6] = {128,512,2*1024,32*1024,128*1024,1024*1024};
        int size_counter;
        for (size_counter=0; size_counter<6; size_counter++){
                int num_elements_per_proc = sizes[size_counter] ;
                /*Generate input for each process*/
                
				if (my_rank==0){
					fp = fopen("00.data", "r");
                	int n = 0;
					
					while (fscanf(fp, "%f", &rand_nums[n++]) != EOF && n<num_elements_per_proc*world_size );
					
					fclose(fp);                       
				} else {
					for(i=0; i < num_elements_per_proc ; i++)
                        rand_nums[i]=0;                        
				}
                

                MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
                
				MPI_Bcast(rand_nums, num_elements_per_proc, MPI_FLOAT, 0, MPI_COMM_WORLD);

               
                if (my_rank==0){
                                    
                        int rank;
                        bool passed = true;                        
                        int j;
                        int gsum=0;
                        for ( rank=1; rank < world_size; rank++){
                                
                                MPI_Recv(input_gsum_buf,num_elements_per_proc, MPI_FLOAT, rank, 3, MPI_COMM_WORLD, &status);
                                
                                for (i = 0; i < num_elements_per_proc; i++) {
                                        if (input_gsum_buf[i] != rand_nums[i]){
                                                printf(RED"TEST: FAIL. RANK %d in i: %d, ROUTINE gsum_buf: %.1f, EXPECTED rand_nums %.1f, SIZE:%d\n"RESET, rank, i, input_gsum_buf[i], rand_nums[i], sizes[size_counter]);
                                                passed = passed && false;
                                                break;
                                        }                                                
                                }
                        }                        

                        if(passed)
                                printf("TEST: PASS, SIZE:%d\n", sizes[size_counter]);

                }else{
					                          
					// int rank = my_rank +1 ;
					// fprintf(stderr," [%d]  %.1f %.1f %.1f %.1f %.1f %.1f %.1f %.1f %.1f \n" ,my_rank,global_sum[0],global_sum[1],global_sum[2],global_sum[3],global_sum[4],global_sum[5],global_sum[6],global_sum[7],global_sum[8]);
					
					MPI_Send(rand_nums,num_elements_per_proc , MPI_FLOAT, 0, 3, MPI_COMM_WORLD);                        
                }
#if 0
                if(world_size >= 4){

                        // if(new_id == 0 )        
                                // fprintf(stderr,"[%d] Start Sub-Comm: new_world_size=%d\n"RESET,my_rank,new_world_size);
                       
                        if (new_id==0) {
							
                                int n = 0;
                                fp = fopen("00.data", "r");                        	
                                
                                while (fscanf(fp, "%f", &rand_nums[n++]) != EOF && n<num_elements_per_proc*new_world_size );

                        	fclose(fp);
                        }  else {
                                for(i=0; i < num_elements_per_proc ; i++)
                                       rand_nums[i]=0;                        
                        }
							
                        MPI_Barrier(New_Comm);

                        fprintf(stderr,"[%d] Start Sub-Comm\n",my_rank);

			MPI_Bcast(rand_nums, num_elements_per_proc, MPI_FLOAT, 0, New_Comm);

                        fprintf(stderr,"[%d] End Sub-Comm\n",my_rank);

                        if (new_id==0){
                                    
                        int rank;
                        bool passed = true;                        
                        // int j;
                        // int gsum=0;
                        for ( rank=1; rank < new_world_size; rank++){
                                
                                MPI_Recv(input_gsum_buf,num_elements_per_proc, MPI_FLOAT, rank, 8, New_Comm, &status);
                                
                                for (i = 0; i < num_elements_per_proc; i++) {
					if (input_gsum_buf[i] != rand_nums[i]){
                                                printf(RED"SUB TEST [%d]: FAIL. RANK %d in i: %d, ROUTINE gsum_buf: %.1f, EXPECTED SUM %.1f, SIZE:%d\n"RESET, my_rank, rank, i, input_gsum_buf[i], rand_nums[i], sizes[size_counter]);
                                                passed = passed && false;
                                                break;
                                        }                                                
                                }
                        }           

                        if(passed)
                                printf("TEST: PASS [Sub-Comm], SIZE:%d\n", sizes[size_counter]);

                        }else{
                                
                                MPI_Send(rand_nums,num_elements_per_proc , MPI_FLOAT, 0, 8, New_Comm);                        
                        }

                        MPI_Barrier(New_Comm);
                        //fprintf(stderr,"[%d] 14\n",my_rank);
                }
                
                MPI_Barrier(MPI_COMM_WORLD); 
#endif				
        }

        MPI_Finalize();
        return EXIT_SUCCESS;
}