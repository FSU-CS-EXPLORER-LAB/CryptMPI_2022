#!/bin/bash

unset MV2_INTER_BCAST_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_CONCURRENT_BCAST
unset MV2_CONCURRENT_COMM


mkdir Default  
./benchmark.sh  
mv out* Default
echo "Default Done"


export MV2_SECURITY_APPROACH=1
mkdir Naive  
./benchmark.sh  
mv out* Naive
echo "Naive Done"  


export MV2_CONCURRENT_BCAST=1
export MV2_SECURITY_APPROACH=0
mkdir CHS  
./benchmark.sh  
mv out* CHS
echo "CHS Done"  

export MV2_CONCURRENT_BCAST=1
export MV2_SECURITY_APPROACH=333
mkdir Enc_CHS  
./benchmark.sh  
mv out* Enc_CHS
echo "Enc_CHS Done"  
