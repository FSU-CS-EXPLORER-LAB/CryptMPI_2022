#!/bin/bash

unset MV2_ALLTOALL_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_CONCURRENT_COMM
unset MV2_INIT_RANK_LIST

mkdir Default
./benchmark.sh
mv out* Default
echo "Default Done"


export MV2_SECURITY_APPROACH=1002
mkdir Naive
./benchmark.sh
mv out* Naive
echo "Naive Done"


export MV2_ALLTOALL_TUNING=0
export MV2_SECURITY_APPROACH=2001
./benchmark.sh
mkdir OBruck
mv out* OBruck
echo "OBruck Done"

export MV2_ALLTOALL_TUNING=2
export MV2_SECURITY_APPROACH=2001
./benchmark.sh
mkdir OSD
mv out* OSD
echo "OSD Done"


export MV2_ALLTOALL_TUNING=5
unset MV2_SECURITY_APPROACH
./benchmark.sh
mkdir CHS
mv out* CHS
echo "CHS Done"

export MV2_ALLTOALL_TUNING=5
export MV2_SECURITY_APPROACH=2002
./benchmark.sh
mkdir Naive_CHS
mv out* Naive_CHS
echo "Naive_CHS Done"

export MV2_ALLTOALL_TUNING=5
export MV2_SECURITY_APPROACH=2001
mkdir O_CHS
./benchmark.sh
mv out* O_CHS
echo "O_CHS Done"


