#!/bin/bash

unset MV2_INTER_GATHER_TUNING
unset MV2_SECURITY_APPROACH

mkdir Default  
./benchmark.sh 
mv out* Default
echo "Default Done"  



export MV2_INTER_GATHER_TUNING=1
mkdir Naive  
./benchmark.sh 
mv out* Naive
echo "Naive Done"  


export MV2_INTER_GATHER_TUNING=3
export MV2_SECURITY_APPROACH=302
mkdir Opp
./small_benchmark.sh
mv out* Opp
echo "Opp Done"


export MV2_INTER_GATHER_TUNING=4
unset MV2_SECURITY_APPROACH
mkdir CHS
./medium_benchmark.sh 
mv out* CHS
echo "CHS Done"  


