#!/bin/bash

unset MV2_INTER_SCATTER_TUNING
unset MV2_SECURITY_APPROACH

mkdir Default  
./benchmark.sh 
mv out* Default
echo "Default Done"  



export MV2_INTER_SCATTER_TUNING=1
export MV2_SECURITY_APPROACH=221
mkdir Naive  
./benchmark.sh 
mv out* Naive
echo "Naive Done"  


export MV2_INTER_SCATTER_TUNING=9
export MV2_SECURITY_APPROACH=200
mkdir HBcast
./small_benchmark.sh
mv out* HBcast
echo "HBcast Done"


export MV2_INTER_SCATTER_TUNING=6
unset MV2_SECURITY_APPROACH
mkdir CHS  
./benchmark.sh 
mv out* CHS
echo "CHS Done"  


export MV2_SECURITY_APPROACH=200
mkdir Enc_CHS  
./benchmark.sh  
mv out* Enc_CHS
echo "Enc_CHS Done"  


export MV2_INTER_SCATTER_TUNING=7
unset MV2_SECURITY_APPROACH
mkdir RR
./benchmark.sh 
mv out* RR
echo "RR Done"  


export MV2_SECURITY_APPROACH=200
mkdir Enc_RR  
./benchmark.sh 
mv out* Enc_RR
echo "Enc_RR Done"  


export MV2_INTER_SCATTER_TUNING=10
unset MV2_SECURITY_APPROACH
mkdir CnoShMem  
./benchmark.sh 
mv out* CnoShMem
echo "CnoShMem Done"  


export MV2_SECURITY_APPROACH=200
mkdir Enc_CnoShMem  
./benchmark.sh 
mv out* Enc_CnoShMem
echo "Enc_CnoShMem Done"  
