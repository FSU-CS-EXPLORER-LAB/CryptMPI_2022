#!/bin/bash

unset MV2_INTER_ALLGATHER_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_SHMEM_LEADERS
unset MV2_CONCURRENT_COMM
unset MV2_INIT_RANK_LIST

mkdir Default
./benchmark.sh 
mv out* Default
echo "Default Done"  



export MV2_INTER_ALLGATHER_TUNING=1
export MV2_SECURITY_APPROACH=1001
mkdir Naive
./benchmark.sh 
mv out* Naive
echo "Naive Done"  


export MV2_INTER_ALLGATHER_TUNING=9 
export MV2_SECURITY_APPROACH=2005
./benchmark.sh 
mkdir ORing
mv out* ORing
echo "ORing Done" 

export MV2_INTER_ALLGATHER_TUNING=10
export MV2_SECURITY_APPROACH=2005
./benchmark.sh 
mkdir ORD
mv out* ORD
echo "ORD Done" 


export MV2_INIT_RANK_LIST=1
export MV2_INTER_ALLGATHER_TUNING=13
unset MV2_SECURITY_APPROACH
./benchmark.sh 
mkdir CRing
mv out* CRing
echo "CRing Done"  

export MV2_SECURITY_APPROACH=2005
echo "Testing Encrypted C-Ring"  
./benchmark.sh 
mkdir Enc_CRing
mv out* Enc_CRing
echo "Enc_CRing Done"  

export MV2_INTER_ALLGATHER_TUNING=12
unset MV2_SECURITY_APPROACH

mkdir CRD  
./benchmark.sh 
mv out* CRD
echo "CRD Done"  

export MV2_SECURITY_APPROACH=2005
mkdir Enc_CRD  
./benchmark.sh 
mv out* Enc_CRD
echo "Enc_CRD Done"  


export MV2_INTER_ALLGATHER_TUNING=18
export MV2_SECURITY_APPROACH=2006

mkdir HS2  
./benchmark.sh 
mv out* HS2
echo "HS2 Done"  


export MV2_INTER_ALLGATHER_TUNING=16
export MV2_SECURITY_APPROACH=2005

mkdir ORD2  
./benchmark.sh  
mv out* ORD2
echo "ORD2 Done"  


export MV2_INTER_ALLGATHER_TUNING=14
unset MV2_SECURITY_APPROACH
mkdir ShMem  
./benchmark.sh 
mv out* ShMem
echo "ShMem Done"  


export MV2_SECURITY_APPROACH=2006
export MV2_SHMEM_LEADERS=1

mkdir HS1  
./benchmark.sh  
mv out* HS1
echo "HS1 Done"  




export MV2_INTER_ALLGATHER_TUNING=20
export MV2_CONCURRENT_COMM=1
unset MV2_SECURITY_APPROACH
mkdir CHS  
./benchmark.sh 
mv out* CHS
echo "CHS Done"  


export MV2_SECURITY_APPROACH=2006
mkdir Enc_CHS
./benchmark.sh 
mv out* Enc_CHS
echo "Enc_CHS Done"  
