#!/bin/bash

source ../config

for((c=1; c<=$ITERAT; c++))
   do
       $MPI_INSTALL_PATH/bin/mpirun -n $RANK -hostfile ../hostfile ./$OSU_BENCH_PATH/osu_allgather -m :2097152 -f >> $OUTPUT
       wait
done

