for((c=1; c<=20; c++))
do
    /home/sadeghil/Installed_Tools/CryptMVAPICH_22/bin/mpirun -n 128 -hostfile hostfile-8-128 ./nbody_256K >> out_128_256K_comm.txt
    /home/sadeghil/Installed_Tools/CryptMVAPICH_22/bin/mpirun -n 128 -hostfile hostfile-8-128 ./nbody_128K >> out_128_128K_comm.txt
    /home/sadeghil/Installed_Tools/CryptMVAPICH_22/bin/mpirun -n 64 -hostfile hostfile-8-64 ./nbody_128K >> out_64_128K_comm.txt
    /home/sadeghil/Installed_Tools/CryptMVAPICH_22/bin/mpirun -n 64 -hostfile hostfile-8-64 ./nbody_64K >> out_64_64K_comm.txt
    /home/sadeghil/Installed_Tools/CryptMVAPICH_22/bin/mpirun -n 32 -hostfile hostfile-8-32 ./nbody_64K >> out_32_64K_comm.txt
    /home/sadeghil/Installed_Tools/CryptMVAPICH_22/bin/mpirun -n 32 -hostfile hostfile-8-32 ./nbody_32K >> out_32_32K_comm.txt
done
