#!/bin/bash

unset MV2_INTER_ALLGATHER_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_SHMEM_LEADERS
unset MV2_CONCURRENT_COMM
unset MV2_INIT_RANK_LIST

echo "Testing Unencrypted Default"  
./benchmark.sh  
mkdir Default
mv out_* Default

export MV2_SECURITY_APPROACH=1001
echo "Testing Naive Default"  
./benchmark.sh  
mkdir Naive
mv out_* Naive

#export MV2_SECURITY_APPROACH=2005
#echo "Testing Opportunistic Default"  
#./benchmark.sh  
#mkdir Opp
#mv out_* Opp

#export MV2_INIT_RANK_LIST=1
#export MV2_INTER_ALLGATHER_TUNING=12
#export MV2_SECURITY_APPROACH=2005
#echo "Testing Encrypted C-Ring"  
#./benchmark.sh  
#mkdir CRing
#mv out_* CRing

#export MV2_INTER_ALLGATHER_TUNING=13
#export MV2_SECURITY_APPROACH=2005
#echo "Testing Encrypted C-RD"  
#./benchmark.sh  
#mkdir CRD
#mv out_* CRD


export MV2_INTER_ALLGATHER_TUNING=18
export MV2_SECURITY_APPROACH=2006
echo "Testing HS2"  
./benchmark.sh  
mkdir HS2
mv out_* HS2


#export MV2_INTER_ALLGATHER_TUNING=17
#export MV2_SECURITY_APPROACH=2005
#echo "Testing O-RD2"  
#./benchmark.sh  
#mkdir ORD2
#mv out_* ORD2


export MV2_INTER_ALLGATHER_TUNING=14
export MV2_SECURITY_APPROACH=2006
export MV2_SHMEM_LEADERS=1
echo "Testing HS1"  
./benchmark.sh  
mkdir HS1
mv out_* HS1


export MV2_INTER_ALLGATHER_TUNING=20
export MV2_CONCURRENT_COMM=1
export MV2_SECURITY_APPROACH=2006
echo "Testing Encrypted CHS"  
./benchmark.sh  
mkdir CHS
mv out_* CHS
