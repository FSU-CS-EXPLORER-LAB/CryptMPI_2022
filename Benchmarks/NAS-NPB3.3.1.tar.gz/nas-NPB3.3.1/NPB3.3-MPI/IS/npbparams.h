#define CLASS 'D'
#define NUM_PROCS 128
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "04 Jun 2022"
#define NPBVERSION "3.3.1"
#define MPICC "$(MYPATH)/bin/mpicc"
#define CFLAGS "-O"
#define CLINK "$(MPICC)"
#define CLINKFLAGS "-O"
#define CMPI_LIB "-L$(MYPATH)/lib -lmpi"
#define CMPI_INC "-I$(MYPATH)/include"
