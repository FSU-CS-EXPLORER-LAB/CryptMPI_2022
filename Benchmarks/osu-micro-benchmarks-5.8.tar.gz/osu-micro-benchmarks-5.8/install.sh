#!/bin/bash
make clean > install.log
make >> install.log
make install >> install.log
