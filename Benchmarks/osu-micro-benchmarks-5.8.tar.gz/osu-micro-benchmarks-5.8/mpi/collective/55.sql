[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 

# OSU MPI Scatter Latency Test v5.8
# Size       Avg Latency(us)
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1] 
[0] Scatter-RR 08 c=1 [r=15]
[1] Scatter-RR 08 c=1 [r=8]
[2] Scatter-RR 08 c=1 [r=8]
[3] Scatter-RR 08 c=1 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
1                       0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[0] Scatter-RR 08 c=2 [r=15]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[1] Scatter-RR 08 c=2 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[2] Scatter-RR 08 c=2 [r=8]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[3] Scatter-RR 08 c=2 [r=8]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
2                       0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[0] Scatter-RR 08 c=4 [r=15]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[1] Scatter-RR 08 c=4 [r=8]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[2] Scatter-RR 08 c=4 [r=8]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[3] Scatter-RR 08 c=4 [r=8]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
4                       0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[0] Scatter-RR 08 c=8 [r=15]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[1] Scatter-RR 08 c=8 [r=8]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[2] Scatter-RR 08 c=8 [r=8]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[3] Scatter-RR 08 c=8 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
8                       0.00
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[0] Scatter-RR 08 c=16 [r=15]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[1] Scatter-RR 08 c=16 [r=8]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[2] Scatter-RR 08 c=16 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[3] Scatter-RR 08 c=16 [r=8]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
16                      0.00
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[0] Scatter-RR 08 c=32 [r=15]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[1] Scatter-RR 08 c=32 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[2] Scatter-RR 08 c=32 [r=8]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[3] Scatter-RR 08 c=32 [r=8]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
32                      0.00
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=64] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[0] Scatter-RR 08 c=64 [r=15]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[1] Scatter-RR 08 c=64 [r=8]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[2] Scatter-RR 08 c=64 [r=8]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[3] Scatter-RR 08 c=64 [r=8]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
64                      0.00
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=128] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[0] Scatter-RR 08 c=128 [r=15]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[1] Scatter-RR 08 c=128 [r=8]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[2] Scatter-RR 08 c=128 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[3] Scatter-RR 08 c=128 [r=8]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
128                     0.00
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=256] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[0] Scatter-RR 08 c=256 [r=15]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[1] Scatter-RR 08 c=256 [r=8]
[2] Scatter-RR 08 c=256 [r=8]
[3] Scatter-RR 08 c=256 [r=8]
256                     0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=512] 
[0] Scatter-RR 08 c=512 [r=15]
[1] Scatter-RR 08 c=512 [r=8]
[2] Scatter-RR 08 c=512 [r=8]
[3] Scatter-RR 08 c=512 [r=8]
512                     0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1024] 
[0] Scatter-RR 08 c=1024 [r=15]
[1] Scatter-RR 08 c=1024 [r=8]
[2] Scatter-RR 08 c=1024 [r=8]
[3] Scatter-RR 08 c=1024 [r=8]
1024                    0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2048] 
[0] Scatter-RR 08 c=2048 [r=15]
[1] Scatter-RR 08 c=2048 [r=8]
[2] Scatter-RR 08 c=2048 [r=8]
[3] Scatter-RR 08 c=2048 [r=8]
2048                    0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4096] 
[0] Scatter-RR 08 c=4096 [r=15]
[1] Scatter-RR 08 c=4096 [r=8]
[2] Scatter-RR 08 c=4096 [r=8]
[3] Scatter-RR 08 c=4096 [r=8]
4096                    0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=8192] 
[0] Scatter-RR 08 c=8192 [r=15]
[1] Scatter-RR 08 c=8192 [r=8]
[2] Scatter-RR 08 c=8192 [r=8]
[3] Scatter-RR 08 c=8192 [r=8]
8192                    0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=16384] 
[0] Scatter-RR 08 c=16384 [r=15]
[1] Scatter-RR 08 c=16384 [r=8]
[2] Scatter-RR 08 c=16384 [r=8]
[3] Scatter-RR 08 c=16384 [r=8]
16384                   0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=32768] 
[0] Scatter-RR 08 c=32768 [r=15]
[1] Scatter-RR 08 c=32768 [r=8]
[2] Scatter-RR 08 c=32768 [r=8]
[3] Scatter-RR 08 c=32768 [r=8]
32768                   0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=65536] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[0] Scatter-RR 08 c=65536 [r=15]
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[1] Scatter-RR 08 c=65536 [r=8]
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[2] Scatter-RR 08 c=65536 [r=8]
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[3] Scatter-RR 08 c=65536 [r=8]
65536                   0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=131072] 
[0] Scatter-RR 08 c=131072 [r=15]
[1] Scatter-RR 08 c=131072 [r=8]
[3] Scatter-RR 08 c=131072 [r=8]
[2] Scatter-RR 08 c=131072 [r=8]
131072                  0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=262144] 
[0] Scatter-RR 08 c=262144 [r=15]
[2] Scatter-RR 08 c=262144 [r=8]
[3] Scatter-RR 08 c=262144 [r=8]
[1] Scatter-RR 08 c=262144 [r=8]
262144                  0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=524288] 
[0] Scatter-RR 08 c=524288 [r=15]
[1] Scatter-RR 08 c=524288 [r=8]
[2] Scatter-RR 08 c=524288 [r=8]
[3] Scatter-RR 08 c=524288 [r=8]
524288                  0.00
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=1048576] 
[0] Scatter-RR 08 c=1048576 [r=15]
[1] Scatter-RR 08 c=1048576 [r=8]
[3] Scatter-RR 08 c=1048576 [r=8]
[2] Scatter-RR 08 c=1048576 [r=8]
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
1048576                 0.00
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=2097152] 
[0] Scatter-RR 08 c=2097152 [r=15]
[1] Scatter-RR 08 c=2097152 [r=8]
[2] Scatter-RR 08 c=2097152 [r=8]
[3] Scatter-RR 08 c=2097152 [r=8]
2097152                 0.00
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 4 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 8 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 12 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 5 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 9 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 13 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 1 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 6 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 10 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 14 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 2 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 7 host = ns02] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 11 host = ns03] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 15 host = ns04] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_index_tuned_intra_MV2
[scatter osu rank = 3 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[scatter osu rank = 0 host = ns01] Func: MPIR_Scatter_MV2_Direct_no_shmem_intra_RR [c=4194304] 
[0] Scatter-RR 08 c=4194304 [r=15]
[1] Scatter-RR 08 c=4194304 [r=8]
[2] Scatter-RR 08 c=4194304 [r=8]
[3] Scatter-RR 08 c=4194304 [r=8]
4194304                 0.00
