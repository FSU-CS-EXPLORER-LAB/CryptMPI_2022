#!/bin/bash

unset MV2_INTER_BCAST_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_CONCURRENT_BCAST
unset MV2_CONCURRENT_COMM


echo "Unencrypted Default"  
./benchmark
mkdir Default
mv out* Default



export MV2_SECURITY_APPROACH=1
echo "Naive Default"  
./benchmark
mkdir Naive
mv out* Naive



export MV2_CONCURRENT_COMM=1
export MV2_CONCURRENT_BCAST=2
export MV2_INTER_BCAST_TUNING=13
export MV2_SECURITY_APPROACH=0
echo "CHS"  
./benchmark
mkdir CHS
mv out* CHS


export MV2_SECURITY_APPROACH=3
echo "Encrypted CHS"  
./benchmark
mkdir Enc-CHS
mv out* Enc-CHS

