#!/bin/bash

unset MV2_INTER_ALLGATHER_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_SHMEM_LEADERS
unset MV2_CONCURRENT_COMM
unset MV2_INIT_RANK_LIST

echo "Unencrypted Default"  
./benchmark
mkdir Default
mv out* Default


export MV2_SECURITY_APPROACH=1001
echo "Naive Default"  
./benchmark
mkdir Naive
mv out* Naive


export MV2_SECURITY_APPROACH=2005
echo "Opportunistic Default"  
./benchmark
mkdir Opp
mv out* Opp


export MV2_INIT_RANK_LIST=1
export MV2_INTER_ALLGATHER_TUNING=12
unset MV2_SECURITY_APPROACH
echo "C-Ring"  
./benchmark
mkdir CRing
mv out* CRing


export MV2_SECURITY_APPROACH=2005
echo "Encrypted C-Ring"  
./benchmark
mkdir Enc-CRing
mv out* Enc-CRing


export MV2_INTER_ALLGATHER_TUNING=13
unset MV2_SECURITY_APPROACH
echo "C-RD"  
./benchmark
mkdir CRD
mv out* CRD


export MV2_SECURITY_APPROACH=2005
echo "Encrypted C-RD"  
./benchmark
mkdir Enc-CRD
mv out* Enc-CRD

export MV2_INTER_ALLGATHER_TUNING=18
export MV2_SECURITY_APPROACH=2006
echo "HS2"  
./benchmark
mkdir HS2
mv out* HS2

export MV2_INTER_ALLGATHER_TUNING=17
export MV2_SECURITY_APPROACH=2005
echo "O-RD2"  
./benchmark
mkdir ORD2
mv out* ORD2


export MV2_INTER_ALLGATHER_TUNING=14
unset MV2_SECURITY_APPROACH
echo "Shared-Mem"  
./benchmark
mkdir ShMem
mv out* ShMem



export MV2_SECURITY_APPROACH=2006
export MV2_SHMEM_LEADERS=1
echo "HS1"  
./benchmark
mkdir HS1
mv out* HS1





export MV2_INTER_ALLGATHER_TUNING=20
export MV2_CONCURRENT_COMM=1
unset MV2_SECURITY_APPROACH
echo "CHS"  
./benchmark
mkdir CHS
mv out* CHS



export MV2_SECURITY_APPROACH=2006
echo "Encrypted CHS"  
./benchmark
mkdir Enc-CHS
mv out* Enc-CHS

