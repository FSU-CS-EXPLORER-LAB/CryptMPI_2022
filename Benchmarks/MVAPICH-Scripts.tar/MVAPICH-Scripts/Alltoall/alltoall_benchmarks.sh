#!/bin/bash

unset MV2_ALLTOALL_TUNING
unset MV2_SECURITY_APPROACH
unset MV2_INTER_ALLGATHER_TUNING
unset MV2_CONCURRENT_COMM

echo "Unencrypted Default"  
./benchmark
mkdir Default
mv out* Default


export MV2_SECURITY_APPROACH=1002
echo "Naive Default"  
./benchmark
mkdir Naive
mv out* Naive


export MV2_ALLTOALL_TUNING=0
export MV2_SECURITY_APPROACH=2001
echo "O-Bruck"  
./benchmark
mkdir OBruck
mv out* OBruck


export MV2_ALLTOALL_TUNING=2
export MV2_SECURITY_APPROACH=2001
echo "O-SD"  
./benchmark
mkdir OSD
mv out* OSD


#export MV2_ALLTOALL_TUNING=5
#unset MV2_SECURITY_APPROACH
export CONCURRENT_COMM=1
#echo "CHS"  
#./benchmark
#mkdir CHS
#mv out* CHS




export MV2_ALLTOALL_TUNING=5
export MV2_SECURITY_APPROACH=2002
echo "Naive CHS"  
./benchmark
mkdir Naive-CHS
mv out* Naive-CHS


export MV2_ALLTOALL_TUNING=5
export MV2_SECURITY_APPROACH=2001
echo "O-CHS"  
./benchmark
mkdir O-CHS
mv out* O-CHS


