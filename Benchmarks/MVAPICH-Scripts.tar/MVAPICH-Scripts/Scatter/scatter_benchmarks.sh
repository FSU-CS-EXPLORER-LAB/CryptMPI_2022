#!/bin/bash

unset MV2_INTER_SCATTER_TUNING
unset MV2_SECURITY_APPROACH

echo "Unencrypted Default"  
./benchmark
mkdir Default
mv out* Default



export MV2_SECURITY_APPROACH=221
echo "Naive Default"  
./benchmark
mkdir Naive
mv out* Naive


export MV2_INTER_SCATTER_TUNING=6
export MV2_CONCURRENT_COMM=1
export MV2_SECURITY_APPROACH=200
echo "Encrypted CHS"  
./benchmark
mkdir Enc-CHS
mv out* Enc-CHS


export MV2_INTER_SCATTER_TUNING=7
export MV2_SECURITY_APPROACH=200
echo "Encrypted RR"  
./benchmark
mkdir Enc-RR
mv out* Enc-RR


export MV2_INTER_SCATTER_TUNING=9
export MV2_SECURITY_APPROACH=200
echo "Encrypted BcastBased"
./benchmark
mkdir Enc-BB
mv out* Enc-BB



export MV2_INTER_SCATTER_TUNING=10
export MV2_SECURITY_APPROACH=200
echo "Encrypted C-noShMem"  
./benchmark
mkdir Enc-CnoShMem
mv out* Enc-CnoShMem
