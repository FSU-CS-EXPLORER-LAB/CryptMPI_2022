#!/bin/bash


cd Alltoall/
rm -r */ -
rm core.*
wait
cd ../BCast
rm -r */ -
rm core.*
wait
cd ../Allgather
rm -r */ -
rm core.*
wait
cd ../Scatter
rm -r */ -
rm core.*
cd ../Gather
rm -r */ -
rm core.*
wait
