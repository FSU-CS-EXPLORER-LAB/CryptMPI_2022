#!/bin/bash

source ../config

for((c=1; c<=$ITERAT; c++))
   do
      $MPI_INSTALL_PATH/bin/mpirun -n $RANK -hostfile ../hostfile ./$OSU_BENCH_PATH/osu_scatter -m :1048576 -f >> $OUTPUT
       wait
done

