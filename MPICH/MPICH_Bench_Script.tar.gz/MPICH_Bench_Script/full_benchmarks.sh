#!/bin/bash

cd Gather
echo "Running Gather benchmark...."
./gather_benchmarks.sh
wait
cd ../Alltoall/
echo "Running Alltoall benchmark...."
./alltoall_benchmarks.sh
wait
cd ../BCast
echo "Running BCast benchmark...."
./bcast_benchmarks.sh
wait
cd ../Allgather
echo "Running Allgather benchmark...."
./allgather_benchmarks.sh
wait
cd ../Scatter
echo "Running Scatter benchmark...."
./scatter_benchmarks.sh
